% NLOPT_GN_DIRECT_NOSCAL: Unscaled DIRECT (global, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_GN_DIRECT_NOSCAL
  val = 3;
