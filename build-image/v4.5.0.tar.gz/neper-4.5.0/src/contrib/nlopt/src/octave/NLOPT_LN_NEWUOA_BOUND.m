% NLOPT_LN_NEWUOA_BOUND: Bound-constrained optimization via NEWUOA-based quadratic models (local, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_LN_NEWUOA_BOUND
  val = 27;
