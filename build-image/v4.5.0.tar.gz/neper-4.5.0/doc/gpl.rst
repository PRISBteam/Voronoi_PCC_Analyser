.. _gpl:

**************************
GNU General Public License
**************************

.. literalinclude:: _static/gpl.txt
