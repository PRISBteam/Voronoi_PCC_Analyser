.. _versions:

********
Versions
********

.. literalinclude:: ../VERSIONS
   :language: plain
